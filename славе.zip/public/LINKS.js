const st=document.getElementById('start');
const ab=document.getElementById("about");
st.addEventListener("click", ()=>{document.location.assign("/game.html")}
    
)
ab.onclick=()=>{
    window.location.assign("/about.html");
}