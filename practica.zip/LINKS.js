const st=document.getElementById('start');
st.onclick=()=>{
    document.location.replace("http://localhost:3000/game.html")
}